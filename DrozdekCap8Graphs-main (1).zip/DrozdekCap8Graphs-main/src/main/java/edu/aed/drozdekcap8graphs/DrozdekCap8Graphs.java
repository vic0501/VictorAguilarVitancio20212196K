package edu.aed.drozdekcap8graphs;

public class DrozdekCap8Graphs {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

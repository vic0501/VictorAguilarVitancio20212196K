/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.nodupstack;

import edu.aed.cap19stack.StackTDA;
import edu.aed.cap19stack.ListStackTDA;

public class NoDupStack<E> implements StackTDA<E> {
    private StackTDA<E> stack;

    public NoDupStack() {
        stack = new ListStackTDA<>();
    }

    public void clear() {
        stack.clear();
    }

    public boolean isEmpty() {
        return stack.isEmpty();
    }

    public E peek() throws StackEmptyExceptionTDA {
        return stack.peek();
    }

    public E pop() throws StackEmptyExceptionTDA {
        return stack.pop();
    }

    public void push(E elemento) {
        if (contains(elemento)) {
            throw new DuplicateExceptionAED("El elemento ya existe en la pila: " + elemento.toString());
        }
        stack.push(elemento);
    }

    public int size() {
        return stack.size();
    }
    public void imprimir() {
        stack.imprimir();
    }

    // Método privado para verificar si la pila ya contiene un elemento igual al proporcionado
    private boolean contains(E element) {
        try {
            E topElement = stack.peek();
            while (topElement != null) {
                if (topElement.equals(element)) {
                    return true;
                }
                stack.pop();
                topElement = stack.peek();
            }
        } catch (StackEmptyExceptionTDA ignored) {
        }

        return false;
    }
}
